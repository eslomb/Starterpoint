<?php
define('WP_DEBUG', false);
define('DB_NAME', 'starterpoint');
define('DB_USER', 'root');
define('DB_PASSWORD', 'pass');
define('WP_HOME','http://starterpoint');
define('WP_SITEURL','http://starterpoint');


/** Host de MySQL (es muy probable que no necesites cambiarlo) */
define('DB_HOST', 'localhost');
define('DB_CHARSET', 'utf8');
define('DB_COLLATE', '');