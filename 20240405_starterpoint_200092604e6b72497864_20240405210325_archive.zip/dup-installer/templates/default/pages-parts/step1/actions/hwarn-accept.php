<?php

/**
 *
 * @package templates/default
 */

defined('ABSPATH') || defined('DUPXABSPATH') || exit;
?>
<div id="hard_warning_action" class="bottom-step-action margin-top-2 no-display" > 
    <p>
        It is not recommended but possible to continue with the installation before<br>
        the problems indicated in the validation have been solved.
    </p>
</div>